from pathlib import Path

import pandas as pd

from aml_analysis import (
    apply_typology_rules,
    compute_composite_risk,
    engineer_features,
    evaluate,
    generate_synthetic_transactions,
    run_isolation_forest,
    run_pipeline,
    run_sensitivity_analysis,
)


def test_generate_synthetic_transactions_respects_requested_counts():
    df = generate_synthetic_transactions(n_normal=20, n_suspicious=7)
    assert len(df) == 27
    assert int(df["is_suspicious"].sum()) == 7


def test_default_pipeline_flags_suspicious_activity_with_strong_recall():
    df = generate_synthetic_transactions()
    df = engineer_features(df)
    df = run_isolation_forest(df)
    df = apply_typology_rules(df)
    df = compute_composite_risk(df)
    results = evaluate(df)

    assert {"ml_only", "rules_only", "combined"} <= results.keys()
    assert results["combined"]["recall"] >= 0.95
    assert df["composite_risk_score"].between(0, 100).all()
    assert df["risk_tier"].isin(["Low", "Medium", "High", "Critical"]).all()


def test_run_pipeline_exports_expected_files(tmp_path: Path):
    df, results = run_pipeline(output_dir=tmp_path, export=True, make_plots=False)

    flagged_path = tmp_path / "flagged_transactions.csv"
    sensitivity_path = tmp_path / "sensitivity_analysis.csv"

    assert flagged_path.exists()
    assert sensitivity_path.exists()
    assert not pd.read_csv(flagged_path).empty
    assert not pd.read_csv(sensitivity_path).empty
    assert results["combined"]["recall"] >= 0.95
    assert len(df) == 1000


def test_sensitivity_analysis_has_expected_columns():
    df = generate_synthetic_transactions(n_normal=200, n_suspicious=40)
    df = engineer_features(df)
    sensitivity = run_sensitivity_analysis(df, contamination_grid=(0.05, 0.10))

    assert list(sensitivity["contamination"]) == [0.05, 0.10]
    assert {
        "precision",
        "recall",
        "f1",
        "true_positives",
        "false_positives",
        "false_negatives",
        "high_critical_count",
    } <= set(sensitivity.columns)
