# BSA/AML Transaction Risk Detection

**Applied machine learning and rule-based typology detection for financial crimes compliance.**

A lightweight, interpretable detection pipeline that combines an Isolation Forest anomaly model with FinCEN-aligned typology rules to produce a prioritized SAR review queue. Built as a portfolio project to demonstrate the intersection of BSA/AML domain expertise and quantitative skills for community bank compliance, financial crimes consulting, and model risk management roles.

---

## System Architecture

```
Raw Transactions (with timestamps)
       │
       ▼
Feature Engineering (9 BSA-relevant features)
       │
       ▼
Stratified Train / Test Split  ──►  Fit Isolation Forest on TRAIN only
       │                                         │
       ▼                                         ▼
Apply to TEST set  ◄── Fitted scaler + model (out-of-sample)
       │
       ├──► ML anomaly score (0–100)
       ├──► Rule-based alerts (4 FinCEN typologies, rolling window)
       │
       ▼
Composite Risk Score (0–100)
  50% ML + 35% Rules + 15% Country Risk
       │
       ▼
Risk Tiers: Low | Medium | High | Critical
       │
       ▼
Prioritized SAR Review Queue  →  flagged_transactions.csv
```

---

## Typologies Covered

| Typology | Regulatory Basis | Detection Method |
|---|---|---|
| Structuring (Smurfing) | 31 CFR § 1020.320 | Rule: ≥3 near-$10k cash deposits per account within a 14-day rolling window |
| Rapid Movement / Layering | FFIEC BSA/AML Manual | Rule: same-day wire in/out + elevated jurisdiction |
| Dormant Account Spike | FFIEC Unusual Activity | Rule + ML: 90+ day gap + high value + off-hours |
| Round-Dollar Anomaly | FinCEN SAR guidance | Rule + ML: statistical rarity of even amounts |

---

## Out-of-Sample Results

Evaluated on a held-out 30% stratified test partition (n=300, 30 suspicious). The model is fit only on the 70% training partition; all metrics below are from the test set.

| Method | Precision | Recall | F1 |
|---|---|---|---|
| ML Only (Isolation Forest) | 80.0% | 93.3% | 86.2% |
| Rules Only | 100.0% | 70.0% | 82.4% |
| **Combined (ML ∪ Rules)** | **81.1%** | **100.0%** | **89.6%** |
| Production Queue (High/Critical tier) | 100.0% | 36.7% | 53.7% |

**Ranked-output metrics (on composite score):**
- ROC-AUC: **0.980**
- PR-AUC: **0.853**

### Reading these numbers

The combined ML ∪ Rules view achieves perfect recall — zero missed suspicious transactions — which is the conservative posture under BSA § 5318(g), where a missed SAR carries far higher regulatory cost than investigator overhead.

The production queue row (High/Critical tier) exposes a real trade-off that the prior in-sample evaluation hid: the default tier cutoffs are strict enough that they catch only 36.7% of suspicious activity at the top of the queue. That's a defensible choice for a triage queue where investigators work top-down, but the gap is surfaced here rather than smoothed over — exactly the kind of finding SR 11-7 ongoing monitoring is designed to produce.

---

## Weight Sensitivity Analysis

SR 11-7 requires composite weights to be documented and challenged. All five weight schemes evaluated on the same test set:

| Weight Scheme | ROC-AUC | PR-AUC |
|---|---|---|
| Default (50/35/15) | 0.980 | 0.853 |
| ML-heavy (70/20/10) | 0.986 | 0.881 |
| Rules-heavy (20/70/10) | 0.977 | 0.868 |
| Equal (33/34/33) | 0.936 | 0.576 |
| **No country (55/45/0)** | **0.997** | **0.971** |

Finding: the country-risk overlay is degrading the composite on this synthetic distribution. In production this would motivate either dropping the country weight or revisiting the country-tier mapping (FATF blacklist vs. greylist calibration). The default weights were kept for the headline results to reflect a realistic bank configuration; the sensitivity table shows the model's behavior if those assumptions are challenged.

---

## Regulatory Alignment

- **BSA § 5318(g)** — SAR filing obligations inform typology rule design
- **31 CFR § 1020.320** — CTR threshold and structuring detection
- **SR 11-7** — Model treated as a documented, validated asset; conceptual soundness, out-of-sample testing, and sensitivity analysis built into the pipeline
- **FFIEC BSA/AML Examination Manual** — Country risk tiers follow FATF blacklist/greylist geography
- **FinCEN Geographic Targeting Orders** — High-risk jurisdiction flags

---

## Tech Stack

- Python 3.11+
- scikit-learn (Isolation Forest, StandardScaler, stratified split, ROC/PR-AUC)
- pandas, NumPy
- matplotlib, seaborn
- pytest (16 unit tests covering rule logic, feature engineering, scoring)

---

## Repo Contents

| File | Description |
|---|---|
| `aml_analysis.py` | Full pipeline: data gen → features → train/test → model → rules → scoring → evaluation → sensitivity |
| `tests/test_pipeline.py` | Unit tests for rule logic, features, composite scoring |
| `requirements.txt` | Pinned minimum versions |
| `flagged_transactions.csv` | Sample output: High/Critical tier transactions (test set) |
| `sensitivity_analysis.csv` | Weight-scheme sensitivity results |
| `aml_visuals.png` | Four-panel visualization of detection results |

---

## Running the Analysis

```bash
pip install -r requirements.txt
python aml_analysis.py
```

Optional flags:

```bash
python aml_analysis.py --seed 123 --output-dir results/
```

Outputs: `flagged_transactions.csv`, `sensitivity_analysis.csv`, and `aml_visuals.png`.

### Running tests

```bash
pytest tests/ -v
```

---

## Model Risk (SR 11-7) Notes

- **Conceptual soundness**: Isolation Forest is appropriate for unsupervised anomaly detection in transaction data. Rules provide a high-precision, regulator-recognized benchmark.
- **Data integrity**: Synthetic data is deterministic (seeded). No data leakage — the model never sees its own test set during fitting.
- **Benchmarking**: Four detection views are compared (ML, rules, union, tier queue) plus two ranked-output metrics.
- **Sensitivity**: Composite weights are stress-tested across five plausible schemes.
- **Ongoing monitoring**: In production, weights and tier cutoffs would be recalibrated quarterly against dispositioned SAR outcomes. This repo demonstrates the scaffolding; the feedback loop is the bank's to operate.
- **Known limitations**: Synthetic labels; the `days_since_last_txn` feature is supplied rather than derived from the timestamp sequence; IF contamination parameter is set a priori rather than tuned.

---

## Background

Built as a portfolio project alongside MScFE coursework (Financial Engineering, Deep Learning for Finance). Targets BSA/AML analyst, financial crimes compliance, and model risk management roles at community banks and regional financial institutions.

---

*Synthetic data only. No real customer or transaction data used.*
