"""
BSA/AML Transaction Risk Detection System
==========================================

Combines Isolation Forest anomaly detection with FinCEN-aligned rule-based
typology alerts to produce a prioritized SAR review queue with a composite
0-100 risk score.

Regulatory alignment:
  - BSA § 5318(g):        SAR filing obligations
  - 31 CFR § 1020.320:    CTR threshold / structuring detection
  - SR 11-7:              Model risk management (documentation, benchmarking,
                          ongoing monitoring, conceptual soundness)
  - FFIEC BSA/AML Examination Manual
  - FinCEN Geographic Targeting Orders

Model risk (SR 11-7) summary:
  - Unsupervised Isolation Forest benchmarks against rule-based detection.
  - Fit on a training partition; all reported metrics are out-of-sample.
  - Composite weights are documented and stress-tested (see
    sensitivity_analysis()).
  - Ground-truth labels are synthetic; real deployments would use
    investigator-dispositioned SAR outcomes for ongoing monitoring.

Data: Synthetic only. No real customer or transaction data used.
"""

from __future__ import annotations

import argparse
import logging
import warnings
from dataclasses import dataclass
from datetime import datetime, timedelta
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from sklearn.ensemble import IsolationForest
from sklearn.metrics import average_precision_score, roc_auc_score
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

# Narrowed warning scope — silence only the noisy matplotlib/seaborn FutureWarnings,
# not everything in the process.
warnings.filterwarnings("ignore", category=FutureWarning, module="seaborn")
warnings.filterwarnings("ignore", category=UserWarning, module="matplotlib")

RANDOM_SEED = 42

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-7s  %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger("aml")


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class Config:
    """Pipeline configuration — all thresholds and weights in one place."""

    # Data
    n_normal: int = 900
    n_suspicious: int = 100
    horizon_days: int = 60  # synthetic timestamp window

    # Isolation Forest
    n_estimators: int = 200
    contamination: float = 0.10

    # Rule thresholds
    structuring_near_ctr_min: float = 9000.0
    structuring_ctr_threshold: float = 10000.0
    structuring_count_threshold: int = 3  # ≥3 near-CTR deposits
    structuring_window_days: int = 14     # within rolling 14-day window
    rapid_movement_min_amount: float = 10000.0
    rapid_movement_max_days_between: int = 1
    dormant_days_threshold: int = 90
    dormant_min_amount: float = 10000.0
    round_dollar_min_amount: float = 25000.0

    # Composite risk score — weights sum to 1.0
    weight_ml: float = 0.50
    weight_rules: float = 0.35
    weight_country: float = 0.15

    # Risk tier cutoffs (on 0–100 composite)
    tier_critical: float = 75.0
    tier_high: float = 55.0
    tier_medium: float = 35.0

    # Train/test
    test_size: float = 0.30


CFG = Config()


# ---------------------------------------------------------------------------
# 1. SYNTHETIC DATA GENERATION
# ---------------------------------------------------------------------------

def generate_synthetic_transactions(
    cfg: Config = CFG, seed: int = RANDOM_SEED
) -> pd.DataFrame:
    """
    Generate a synthetic transaction dataset embedding four FinCEN typologies:
      - Structuring (smurfing)          — 31 CFR § 1020.320
      - Rapid movement / layering       — FFIEC BSA/AML Manual
      - Dormant account spikes          — FFIEC unusual activity
      - Round-dollar anomalies          — FinCEN SAR guidance

    Each transaction gets a synthetic timestamp across a `horizon_days`
    window so the structuring rule can operate on a true rolling window.
    """
    rng = np.random.default_rng(seed)
    start = datetime(2025, 1, 1)

    def random_dates(n: int) -> list[datetime]:
        return [start + timedelta(days=int(d), hours=int(h))
                for d, h in zip(
                    rng.integers(0, cfg.horizon_days, n),
                    rng.integers(0, 24, n),
                )]

    # --- Normal transactions ---
    normal = pd.DataFrame({
        "transaction_id": [f"TXN{i:06d}" for i in range(cfg.n_normal)],
        "account_id": rng.integers(1000, 1100, cfg.n_normal),
        "amount": np.abs(rng.lognormal(mean=6.0, sigma=1.2, size=cfg.n_normal)),
        "transaction_type": rng.choice(
            ["deposit", "withdrawal", "wire_in", "wire_out", "ach"],
            size=cfg.n_normal,
            p=[0.35, 0.30, 0.10, 0.10, 0.15],
        ),
        "hour": rng.integers(6, 20, cfg.n_normal),
        "day_of_week": rng.integers(0, 7, cfg.n_normal),
        "days_since_last_txn": rng.exponential(scale=2.0, size=cfg.n_normal).astype(int),
        "counterparty_country_risk": rng.choice(
            [1, 2, 3], size=cfg.n_normal, p=[0.85, 0.12, 0.03]
        ),
        "transaction_date": random_dates(cfg.n_normal),
        "is_suspicious": 0,
    })

    suspicious_rows: list[dict] = []
    per_type = cfg.n_suspicious // 4

    # Structuring: a handful of accounts each making 3–5 near-CTR deposits
    # within a short window. This way the rolling-window rule has signal.
    struct_accounts = rng.integers(2000, 2020, size=max(per_type // 3, 3))
    for idx in range(per_type):
        account = int(rng.choice(struct_accounts))
        base_day = int(rng.integers(0, cfg.horizon_days - cfg.structuring_window_days))
        offset = int(rng.integers(0, cfg.structuring_window_days))
        ts = start + timedelta(days=base_day + offset, hours=int(rng.integers(9, 17)))
        suspicious_rows.append({
            "transaction_id": f"TXN_SUS_S{idx:04d}",
            "account_id": account,
            "amount": float(rng.uniform(9000, 9900)),
            "transaction_type": "deposit",
            "hour": ts.hour,
            "day_of_week": ts.weekday(),
            "days_since_last_txn": int(rng.integers(0, 2)),
            "counterparty_country_risk": 1,
            "transaction_date": ts,
            "is_suspicious": 1,
        })

    # Rapid movement: same-day wire in/out to elevated-risk jurisdictions
    for idx in range(per_type):
        ts = start + timedelta(
            days=int(rng.integers(0, cfg.horizon_days)),
            hours=int(rng.integers(9, 17)),
        )
        suspicious_rows.append({
            "transaction_id": f"TXN_SUS_R{idx:04d}",
            "account_id": int(rng.integers(2020, 2040)),
            "amount": float(rng.uniform(25000, 90000)),
            "transaction_type": str(rng.choice(["wire_in", "wire_out"])),
            "hour": ts.hour,
            "day_of_week": ts.weekday(),
            "days_since_last_txn": 0,
            "counterparty_country_risk": int(rng.choice([2, 3], p=[0.4, 0.6])),
            "transaction_date": ts,
            "is_suspicious": 1,
        })

    # Dormant account spike: long gap + high value + off-hours / weekend
    for idx in range(per_type):
        hour = int(rng.choice([1, 2, 3, 4, 22, 23]))
        ts = start + timedelta(
            days=int(rng.integers(cfg.horizon_days - 10, cfg.horizon_days)),
            hours=hour,
        )
        suspicious_rows.append({
            "transaction_id": f"TXN_SUS_D{idx:04d}",
            "account_id": int(rng.integers(2040, 2060)),
            "amount": float(rng.uniform(15000, 75000)),
            "transaction_type": str(rng.choice(["withdrawal", "wire_out"])),
            "hour": hour,
            "day_of_week": int(rng.choice([5, 6])),
            "days_since_last_txn": int(rng.integers(90, 365)),
            "counterparty_country_risk": int(rng.choice([1, 2])),
            "transaction_date": ts,
            "is_suspicious": 1,
        })

    # Round-dollar anomaly
    for idx in range(per_type):
        ts = start + timedelta(
            days=int(rng.integers(0, cfg.horizon_days)),
            hours=int(rng.integers(9, 17)),
        )
        suspicious_rows.append({
            "transaction_id": f"TXN_SUS_Z{idx:04d}",
            "account_id": int(rng.integers(2060, 2080)),
            "amount": float(rng.choice([25000, 50000, 75000, 100000])),
            "transaction_type": "wire_out",
            "hour": ts.hour,
            "day_of_week": ts.weekday(),
            "days_since_last_txn": int(rng.integers(0, 10)),
            "counterparty_country_risk": int(rng.choice([1, 2, 3])),
            "transaction_date": ts,
            "is_suspicious": 1,
        })

    df = pd.concat([normal, pd.DataFrame(suspicious_rows)], ignore_index=True)
    df = df.sample(frac=1, random_state=seed).reset_index(drop=True)
    return df


# ---------------------------------------------------------------------------
# 2. FEATURE ENGINEERING
# ---------------------------------------------------------------------------

FEATURE_COLS: list[str] = [
    "amount_log", "is_near_ctr", "is_round_dollar", "is_off_hours",
    "is_weekend", "is_dormant_reactivation", "days_since_last_txn",
    "counterparty_country_risk", "hour",
]


def engineer_features(df: pd.DataFrame, cfg: Config = CFG) -> pd.DataFrame:
    """Derive BSA-relevant features. No data leakage from labels."""
    df = df.copy()
    df["amount_log"] = np.log1p(df["amount"])
    df["is_near_ctr"] = (
        (df["amount"] >= cfg.structuring_near_ctr_min)
        & (df["amount"] < cfg.structuring_ctr_threshold)
    ).astype(int)
    df["is_round_dollar"] = (df["amount"] % 1000 == 0).astype(int)
    df["is_off_hours"] = ((df["hour"] < 6) | (df["hour"] > 20)).astype(int)
    df["is_weekend"] = (df["day_of_week"] >= 5).astype(int)
    df["is_dormant_reactivation"] = (
        df["days_since_last_txn"] > cfg.dormant_days_threshold
    ).astype(int)
    return df


# ---------------------------------------------------------------------------
# 3. ISOLATION FOREST — UNSUPERVISED ANOMALY DETECTION
# ---------------------------------------------------------------------------

@dataclass
class FittedModel:
    """Carries the fitted transformer + model so test data uses the same scaler."""
    scaler: StandardScaler
    model: IsolationForest
    score_min: float
    score_max: float


def fit_isolation_forest(
    df_train: pd.DataFrame, cfg: Config = CFG, seed: int = RANDOM_SEED
) -> FittedModel:
    """Fit scaler + Isolation Forest on training partition only."""
    X = df_train[FEATURE_COLS].values
    scaler = StandardScaler().fit(X)
    X_scaled = scaler.transform(X)

    model = IsolationForest(
        n_estimators=cfg.n_estimators,
        contamination=cfg.contamination,
        random_state=seed,
        n_jobs=-1,
    )
    model.fit(X_scaled)

    # Capture training score range for consistent 0–100 normalization at inference.
    raw = model.decision_function(X_scaled)
    return FittedModel(
        scaler=scaler,
        model=model,
        score_min=float(raw.min()),
        score_max=float(raw.max()),
    )


def score_isolation_forest(df: pd.DataFrame, fitted: FittedModel) -> pd.DataFrame:
    """Apply a fitted IF model — use on train and test partitions."""
    df = df.copy()
    X_scaled = fitted.scaler.transform(df[FEATURE_COLS].values)
    raw = fitted.model.decision_function(X_scaled)
    score_range = fitted.score_max - fitted.score_min
    if score_range == 0:
        df["ml_anomaly_score"] = 0.0
    else:
        df["ml_anomaly_score"] = np.clip(
            100 * (fitted.score_max - raw) / score_range, 0, 100
        )
    df["ml_flag"] = (fitted.model.predict(X_scaled) == -1).astype(int)
    return df


# ---------------------------------------------------------------------------
# 4. RULE-BASED TYPOLOGY ALERTS
# ---------------------------------------------------------------------------

def apply_typology_rules(df: pd.DataFrame, cfg: Config = CFG) -> pd.DataFrame:
    """
    Apply FinCEN-aligned typology rules. Each rule emits a 0/1 flag; the
    rule_flag_count rolls them up for the composite score.

    Rule 1 — Structuring (rolling window):
        ≥3 near-CTR cash deposits from the same account within
        `structuring_window_days`. The rolling window makes this faithful
        to 31 CFR § 1020.320 intent rather than counting globally.
    """
    df = df.copy()

    # --- Rule 1: structuring with a true rolling window ---
    df["rule_structuring"] = 0
    if "transaction_date" in df.columns:
        near_ctr = df[df["is_near_ctr"] == 1].copy()
        if not near_ctr.empty:
            near_ctr = near_ctr.sort_values(["account_id", "transaction_date"])
            flagged_ids: set = set()
            window = pd.Timedelta(days=cfg.structuring_window_days)
            for _, group in near_ctr.groupby("account_id", sort=False):
                times = group["transaction_date"].to_numpy()
                ids = group["transaction_id"].to_numpy()
                # Sliding window pointer
                left = 0
                for right in range(len(times)):
                    while times[right] - times[left] > window:
                        left += 1
                    if right - left + 1 >= cfg.structuring_count_threshold:
                        flagged_ids.update(ids[left : right + 1])
            df.loc[df["transaction_id"].isin(flagged_ids), "rule_structuring"] = 1

    # --- Rule 2: rapid movement ---
    df["rule_rapid_movement"] = (
        df["transaction_type"].isin(["wire_in", "wire_out"])
        & (df["amount"] > cfg.rapid_movement_min_amount)
        & (df["days_since_last_txn"] <= cfg.rapid_movement_max_days_between)
        & (df["counterparty_country_risk"] >= 2)
    ).astype(int)

    # --- Rule 3: dormant spike ---
    df["rule_dormant_spike"] = (
        (df["is_dormant_reactivation"] == 1) & (df["amount"] > cfg.dormant_min_amount)
    ).astype(int)

    # --- Rule 4: round-dollar anomaly ---
    df["rule_round_dollar"] = (
        (df["is_round_dollar"] == 1) & (df["amount"] >= cfg.round_dollar_min_amount)
    ).astype(int)

    rule_cols = ["rule_structuring", "rule_rapid_movement",
                 "rule_dormant_spike", "rule_round_dollar"]
    df["rule_flag_count"] = df[rule_cols].sum(axis=1)
    df["rule_flag"] = (df["rule_flag_count"] > 0).astype(int)
    return df


# ---------------------------------------------------------------------------
# 5. COMPOSITE RISK SCORE
# ---------------------------------------------------------------------------

def _score_to_tier(score: float, cfg: Config = CFG) -> str:
    if score >= cfg.tier_critical:
        return "Critical"
    if score >= cfg.tier_high:
        return "High"
    if score >= cfg.tier_medium:
        return "Medium"
    return "Low"


def compute_composite_risk(df: pd.DataFrame, cfg: Config = CFG) -> pd.DataFrame:
    """
    Composite score rationale (SR 11-7 documentation):
      - ML (50%): detects unknown-pattern anomalies; broad recall.
      - Rules (35%): high-precision, regulator-recognized typologies.
      - Country risk (15%): jurisdictional overlay per FFIEC/FATF.

    Weights reviewed via sensitivity_analysis(); default set favors recall,
    which is the conservative posture for SAR filing obligations under
    BSA § 5318(g) where missed filings carry higher regulatory cost than
    false positives.
    """
    df = df.copy()
    country_norm = (df["counterparty_country_risk"] - 1) * 50  # 0, 50, 100
    rule_norm = np.clip(df["rule_flag_count"] * 33, 0, 100)

    df["composite_risk_score"] = (
        cfg.weight_ml * df["ml_anomaly_score"]
        + cfg.weight_rules * rule_norm
        + cfg.weight_country * country_norm
    ).round(1)
    df["risk_tier"] = df["composite_risk_score"].apply(lambda s: _score_to_tier(s, cfg))
    return df


# ---------------------------------------------------------------------------
# 6. EVALUATION
# ---------------------------------------------------------------------------

def _binary_metrics(y_true: np.ndarray, y_pred: np.ndarray) -> dict:
    tp = int(((y_true == 1) & (y_pred == 1)).sum())
    fp = int(((y_true == 0) & (y_pred == 1)).sum())
    fn = int(((y_true == 1) & (y_pred == 0)).sum())
    tn = int(((y_true == 0) & (y_pred == 0)).sum())
    precision = tp / (tp + fp) if (tp + fp) else 0.0
    recall = tp / (tp + fn) if (tp + fn) else 0.0
    f1 = 2 * precision * recall / (precision + recall) if (precision + recall) else 0.0
    return {"precision": precision, "recall": recall, "f1": f1,
            "tp": tp, "fp": fp, "fn": fn, "tn": tn}


def evaluate(df: pd.DataFrame) -> dict:
    """
    Evaluate all four views of the system:
      1. ML-only flag
      2. Rules-only flag
      3. Combined flag (ML ∪ Rules)
      4. Production artifact: High/Critical tier queue  ← this is what ships

    Plus ranked-output metrics (ROC-AUC, PR-AUC) on the composite score,
    which is the honest way to evaluate a score-based queue.
    """
    y = df["is_suspicious"].to_numpy()

    combined_flag = ((df["ml_flag"] == 1) | (df["rule_flag"] == 1)).astype(int).to_numpy()
    tier_flag = df["risk_tier"].isin(["High", "Critical"]).astype(int).to_numpy()

    out = {
        "ml_only":            _binary_metrics(y, df["ml_flag"].to_numpy()),
        "rules_only":         _binary_metrics(y, df["rule_flag"].to_numpy()),
        "combined":           _binary_metrics(y, combined_flag),
        "tier_high_critical": _binary_metrics(y, tier_flag),
        "roc_auc":            float(roc_auc_score(y, df["composite_risk_score"])),
        "pr_auc":             float(average_precision_score(y, df["composite_risk_score"])),
    }
    return out


def sensitivity_analysis(df: pd.DataFrame) -> pd.DataFrame:
    """
    Stress-test the composite weights. Required reading for any reviewer
    asking 'why 50/35/15?'. We re-score the test set under several plausible
    weight schemes and report ROC-AUC / PR-AUC for each.
    """
    y = df["is_suspicious"].to_numpy()
    rule_norm = np.clip(df["rule_flag_count"] * 33, 0, 100).to_numpy()
    country_norm = ((df["counterparty_country_risk"] - 1) * 50).to_numpy()
    ml = df["ml_anomaly_score"].to_numpy()

    schemes = [
        ("Default (50/35/15)",     0.50, 0.35, 0.15),
        ("ML-heavy (70/20/10)",    0.70, 0.20, 0.10),
        ("Rules-heavy (20/70/10)", 0.20, 0.70, 0.10),
        ("Equal (33/34/33)",       0.33, 0.34, 0.33),
        ("No country (55/45/0)",   0.55, 0.45, 0.00),
    ]

    rows = []
    for label, w_ml, w_rules, w_country in schemes:
        score = w_ml * ml + w_rules * rule_norm + w_country * country_norm
        rows.append({
            "scheme": label,
            "roc_auc": roc_auc_score(y, score),
            "pr_auc": average_precision_score(y, score),
        })
    return pd.DataFrame(rows)


# ---------------------------------------------------------------------------
# 7. VISUALS
# ---------------------------------------------------------------------------

def make_visuals(df: pd.DataFrame, outpath: str | Path = "aml_visuals.png") -> None:
    sns.set_style("whitegrid")
    fig, axes = plt.subplots(2, 2, figsize=(14, 10))
    fig.suptitle("BSA/AML Transaction Risk Detection — Test Set Results",
                 fontsize=15, fontweight="bold")

    # Panel 1: risk score distribution
    ax = axes[0, 0]
    for label, sub in df.groupby("is_suspicious"):
        ax.hist(sub["composite_risk_score"], bins=30, alpha=0.6,
                label="Suspicious" if label == 1 else "Normal")
    ax.set_title("Composite Risk Score Distribution")
    ax.set_xlabel("Risk Score (0–100)")
    ax.legend()

    # Panel 2: ML vs Rules overlap
    ax = axes[0, 1]
    overlap = pd.crosstab(df["ml_flag"], df["rule_flag"])
    sns.heatmap(overlap, annot=True, fmt="d", cmap="Blues", ax=ax)
    ax.set_title("ML Flag vs Rule Flag (Detection Overlap)")
    ax.set_xlabel("Rule Flag")
    ax.set_ylabel("ML Flag")

    # Panel 3: Amount by transaction type
    ax = axes[1, 0]
    df_plot = df.copy()
    df_plot["status"] = df_plot["is_suspicious"].map({0: "Normal", 1: "Suspicious"})
    sns.boxplot(data=df_plot, x="transaction_type", y="amount",
                hue="status", ax=ax)
    ax.set_yscale("log")
    ax.set_title("Transaction Amount by Type (log)")
    ax.tick_params(axis="x", rotation=30)

    # Panel 4: Risk tier counts
    ax = axes[1, 1]
    tier_order = ["Low", "Medium", "High", "Critical"]
    tier_counts = df["risk_tier"].value_counts().reindex(tier_order).fillna(0)
    colors = ["#10b981", "#f59e0b", "#ef4444", "#991b1b"]
    ax.bar(tier_counts.index, tier_counts.values, color=colors)
    ax.set_title("Transactions by Risk Tier")
    ax.set_ylabel("Count")
    for i, v in enumerate(tier_counts.values):
        ax.text(i, v + 2, str(int(v)), ha="center", fontweight="bold")

    plt.tight_layout()
    plt.savefig(outpath, dpi=150, bbox_inches="tight")
    plt.close()
    log.info("Saved: %s", outpath)


# ---------------------------------------------------------------------------
# MAIN PIPELINE
# ---------------------------------------------------------------------------

def run_pipeline(cfg: Config = CFG, seed: int = RANDOM_SEED,
                 output_dir: Path = Path(".")) -> dict:
    output_dir.mkdir(parents=True, exist_ok=True)

    log.info("=" * 68)
    log.info("BSA/AML Transaction Risk Detection — run started")
    log.info("=" * 68)

    log.info("[1/7] Generating synthetic transactions")
    df = generate_synthetic_transactions(cfg, seed=seed)
    log.info("       Total: %d  |  Suspicious (ground truth): %d",
             len(df), int(df["is_suspicious"].sum()))

    log.info("[2/7] Engineering features")
    df = engineer_features(df, cfg)

    log.info("[3/7] Train/test split (stratified)")
    train, test = train_test_split(
        df, test_size=cfg.test_size, random_state=seed,
        stratify=df["is_suspicious"],
    )
    log.info("       Train: %d  |  Test: %d  (suspicious in test: %d)",
             len(train), len(test), int(test["is_suspicious"].sum()))

    log.info("[4/7] Fitting Isolation Forest on TRAIN partition")
    fitted = fit_isolation_forest(train, cfg, seed=seed)

    log.info("[5/7] Scoring TEST partition and applying rules")
    scored = score_isolation_forest(test, fitted)
    scored = apply_typology_rules(scored, cfg)
    scored = compute_composite_risk(scored, cfg)

    log.info("[6/7] Evaluating (out-of-sample)")
    results = evaluate(scored)
    log.info("")
    log.info("  %-22s %10s %10s %10s", "Method", "Precision", "Recall", "F1")
    log.info("  %s", "-" * 54)
    for name in ("ml_only", "rules_only", "combined", "tier_high_critical"):
        m = results[name]
        log.info("  %-22s %9.1f%% %9.1f%% %9.1f%%",
                 name, m["precision"] * 100, m["recall"] * 100, m["f1"] * 100)
    log.info("")
    log.info("  Composite score ROC-AUC:  %.3f", results["roc_auc"])
    log.info("  Composite score PR-AUC:   %.3f", results["pr_auc"])

    log.info("[7/7] Sensitivity analysis on composite weights")
    sens = sensitivity_analysis(scored)
    log.info("")
    for _, row in sens.iterrows():
        log.info("  %-25s  ROC-AUC: %.3f  PR-AUC: %.3f",
                 row["scheme"], row["roc_auc"], row["pr_auc"])

    # --- Export artifacts ---
    flagged = scored[scored["risk_tier"].isin(["High", "Critical"])].sort_values(
        "composite_risk_score", ascending=False
    )
    export_cols = [
        "transaction_id", "account_id", "transaction_date", "amount",
        "transaction_type", "composite_risk_score", "risk_tier",
        "ml_anomaly_score", "rule_structuring", "rule_rapid_movement",
        "rule_dormant_spike", "rule_round_dollar", "counterparty_country_risk",
    ]
    flagged_path = output_dir / "flagged_transactions.csv"
    flagged[export_cols].to_csv(flagged_path, index=False)
    log.info("")
    log.info("Exported %d High/Critical transactions → %s",
             len(flagged), flagged_path)

    sens_path = output_dir / "sensitivity_analysis.csv"
    sens.to_csv(sens_path, index=False)
    log.info("Exported sensitivity analysis → %s", sens_path)

    make_visuals(scored, output_dir / "aml_visuals.png")

    log.info("Run complete.")
    return {"scored": scored, "results": results, "sensitivity": sens}


def _parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="BSA/AML risk detection pipeline")
    p.add_argument("--seed", type=int, default=RANDOM_SEED,
                   help="Random seed for reproducibility")
    p.add_argument("--output-dir", type=Path, default=Path("."),
                   help="Directory for CSV + PNG outputs")
    return p.parse_args()


if __name__ == "__main__":
    args = _parse_args()
    run_pipeline(seed=args.seed, output_dir=args.output_dir)
