"""
Unit tests for BSA/AML pipeline components.

Run with: pytest tests/
"""

from datetime import datetime, timedelta

import numpy as np
import pandas as pd
import pytest

from aml_analysis import (
    CFG,
    apply_typology_rules,
    compute_composite_risk,
    engineer_features,
    generate_synthetic_transactions,
    _score_to_tier,
)


# ---------------------------------------------------------------------------
# Feature engineering
# ---------------------------------------------------------------------------

def test_is_near_ctr_flags_9000_to_9999():
    df = pd.DataFrame({
        "amount": [8999, 9000, 9500, 9999, 10000, 10001],
        "hour": [12] * 6, "day_of_week": [1] * 6,
        "days_since_last_txn": [0] * 6,
    })
    out = engineer_features(df)
    assert out["is_near_ctr"].tolist() == [0, 1, 1, 1, 0, 0]


def test_is_round_dollar_only_multiples_of_1000():
    df = pd.DataFrame({
        "amount": [999, 1000, 1500, 25000, 25001],
        "hour": [12] * 5, "day_of_week": [1] * 5,
        "days_since_last_txn": [0] * 5,
    })
    out = engineer_features(df)
    assert out["is_round_dollar"].tolist() == [0, 1, 0, 1, 0]


def test_off_hours_excludes_business_hours():
    df = pd.DataFrame({
        "amount": [1000] * 5,
        "hour": [3, 6, 12, 20, 23],
        "day_of_week": [1] * 5,
        "days_since_last_txn": [0] * 5,
    })
    out = engineer_features(df)
    assert out["is_off_hours"].tolist() == [1, 0, 0, 0, 1]


def test_dormant_reactivation_requires_90_plus_days():
    df = pd.DataFrame({
        "amount": [1000] * 4,
        "hour": [12] * 4, "day_of_week": [1] * 4,
        "days_since_last_txn": [30, 89, 90, 91],
    })
    out = engineer_features(df)
    assert out["is_dormant_reactivation"].tolist() == [0, 0, 0, 1]


# ---------------------------------------------------------------------------
# Structuring rule (rolling window)
# ---------------------------------------------------------------------------

def _base_row(**overrides):
    row = {
        "transaction_id": "TXN_X",
        "account_id": 5000,
        "amount": 9500.0,
        "transaction_type": "deposit",
        "hour": 12,
        "day_of_week": 2,
        "days_since_last_txn": 5,
        "counterparty_country_risk": 1,
        "transaction_date": datetime(2025, 1, 1, 12),
        "is_suspicious": 0,
    }
    row.update(overrides)
    return row


def test_structuring_rule_triggers_with_three_deposits_in_window():
    base = datetime(2025, 1, 1, 12)
    df = pd.DataFrame([
        _base_row(transaction_id="A", transaction_date=base),
        _base_row(transaction_id="B", transaction_date=base + timedelta(days=3)),
        _base_row(transaction_id="C", transaction_date=base + timedelta(days=10)),
    ])
    df = engineer_features(df)
    out = apply_typology_rules(df)
    assert out["rule_structuring"].sum() == 3


def test_structuring_rule_does_not_trigger_outside_window():
    # Three near-CTR deposits but spread over 30 days > 14-day window
    base = datetime(2025, 1, 1, 12)
    df = pd.DataFrame([
        _base_row(transaction_id="A", transaction_date=base),
        _base_row(transaction_id="B", transaction_date=base + timedelta(days=15)),
        _base_row(transaction_id="C", transaction_date=base + timedelta(days=30)),
    ])
    df = engineer_features(df)
    out = apply_typology_rules(df)
    assert out["rule_structuring"].sum() == 0


def test_structuring_rule_requires_same_account():
    base = datetime(2025, 1, 1, 12)
    df = pd.DataFrame([
        _base_row(transaction_id="A", account_id=1, transaction_date=base),
        _base_row(transaction_id="B", account_id=2, transaction_date=base + timedelta(days=1)),
        _base_row(transaction_id="C", account_id=3, transaction_date=base + timedelta(days=2)),
    ])
    df = engineer_features(df)
    out = apply_typology_rules(df)
    assert out["rule_structuring"].sum() == 0


def test_structuring_rule_ignores_below_threshold_counts():
    base = datetime(2025, 1, 1, 12)
    df = pd.DataFrame([
        _base_row(transaction_id="A", transaction_date=base),
        _base_row(transaction_id="B", transaction_date=base + timedelta(days=1)),
    ])
    df = engineer_features(df)
    out = apply_typology_rules(df)
    # 2 deposits < threshold of 3
    assert out["rule_structuring"].sum() == 0


# ---------------------------------------------------------------------------
# Other rules
# ---------------------------------------------------------------------------

def test_rapid_movement_rule():
    df = pd.DataFrame([
        # Qualifies: wire_out > 10k, same-day, country risk 3
        _base_row(transaction_id="A", amount=25000, transaction_type="wire_out",
                  days_since_last_txn=0, counterparty_country_risk=3),
        # Disqualified: domestic (country risk 1)
        _base_row(transaction_id="B", amount=25000, transaction_type="wire_out",
                  days_since_last_txn=0, counterparty_country_risk=1),
        # Disqualified: deposit, not wire
        _base_row(transaction_id="C", amount=25000, transaction_type="deposit",
                  days_since_last_txn=0, counterparty_country_risk=3),
        # Disqualified: 3 days between
        _base_row(transaction_id="D", amount=25000, transaction_type="wire_out",
                  days_since_last_txn=3, counterparty_country_risk=3),
    ])
    df = engineer_features(df)
    out = apply_typology_rules(df)
    assert out.set_index("transaction_id")["rule_rapid_movement"].to_dict() == {
        "A": 1, "B": 0, "C": 0, "D": 0,
    }


def test_dormant_spike_requires_both_dormancy_and_amount():
    df = pd.DataFrame([
        _base_row(transaction_id="A", amount=50000, days_since_last_txn=120),  # Yes
        _base_row(transaction_id="B", amount=5000, days_since_last_txn=120),   # No (low amount)
        _base_row(transaction_id="C", amount=50000, days_since_last_txn=30),   # No (not dormant)
    ])
    df = engineer_features(df)
    out = apply_typology_rules(df)
    assert out.set_index("transaction_id")["rule_dormant_spike"].to_dict() == {
        "A": 1, "B": 0, "C": 0,
    }


def test_round_dollar_requires_25k_plus():
    df = pd.DataFrame([
        _base_row(transaction_id="A", amount=25000),  # Yes
        _base_row(transaction_id="B", amount=24000),  # No (below 25k)
        _base_row(transaction_id="C", amount=25500),  # No (not round)
        _base_row(transaction_id="D", amount=100000), # Yes
    ])
    df = engineer_features(df)
    out = apply_typology_rules(df)
    assert out.set_index("transaction_id")["rule_round_dollar"].to_dict() == {
        "A": 1, "B": 0, "C": 0, "D": 1,
    }


# ---------------------------------------------------------------------------
# Composite scoring & tiers
# ---------------------------------------------------------------------------

def test_tier_cutoffs():
    assert _score_to_tier(0) == "Low"
    assert _score_to_tier(34.9) == "Low"
    assert _score_to_tier(35) == "Medium"
    assert _score_to_tier(54.9) == "Medium"
    assert _score_to_tier(55) == "High"
    assert _score_to_tier(74.9) == "High"
    assert _score_to_tier(75) == "Critical"
    assert _score_to_tier(100) == "Critical"


def test_composite_weights_sum_to_one():
    assert abs(CFG.weight_ml + CFG.weight_rules + CFG.weight_country - 1.0) < 1e-9


def test_composite_score_formula():
    # Craft a row with known ml score, 2 rule flags, country risk 2
    df = pd.DataFrame([{
        "ml_anomaly_score": 50.0,
        "rule_flag_count": 2,
        "counterparty_country_risk": 2,
    }])
    out = compute_composite_risk(df)
    # Expected: 0.50 * 50 + 0.35 * min(2*33,100) + 0.15 * 50
    #         = 25 + 23.1 + 7.5 = 55.6
    assert out["composite_risk_score"].iloc[0] == pytest.approx(55.6, abs=0.1)
    assert out["risk_tier"].iloc[0] == "High"


# ---------------------------------------------------------------------------
# End-to-end smoke test
# ---------------------------------------------------------------------------

def test_synthetic_data_generator_is_reproducible():
    df1 = generate_synthetic_transactions(seed=123)
    df2 = generate_synthetic_transactions(seed=123)
    pd.testing.assert_frame_equal(df1, df2)


def test_synthetic_data_shape_matches_config():
    df = generate_synthetic_transactions(CFG)
    assert len(df) == CFG.n_normal + CFG.n_suspicious
    assert df["is_suspicious"].sum() == CFG.n_suspicious
    # All the columns downstream stages depend on exist
    for col in ["transaction_id", "account_id", "amount", "transaction_type",
                "hour", "day_of_week", "days_since_last_txn",
                "counterparty_country_risk", "transaction_date", "is_suspicious"]:
        assert col in df.columns
